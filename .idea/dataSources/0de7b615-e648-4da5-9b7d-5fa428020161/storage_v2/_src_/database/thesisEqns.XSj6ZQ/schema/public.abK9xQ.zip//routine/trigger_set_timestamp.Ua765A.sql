create function trigger_set_timestamp() returns trigger
    language plpgsql
as
$$
BEGIN
        new.modified_at = now();
        RETURN new;
    END;
$$;

alter function trigger_set_timestamp() owner to razor;

