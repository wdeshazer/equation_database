create function trigger_insertion_order_eqn() returns trigger
    language plpgsql
as
$$
DECLARE
        the_count integer;
    BEGIN
        if new.insertion_order is NULL then
            SELECT INTO the_count COUNT(equation_id) FROM equation_eqn_group WHERE eqn_group_id = new.eqn_group_id;
            new.insertion_order = the_count + 1;
            new.insertion_order_prev := the_count + 1;
        end if;
        RETURN new;
    END;
$$;

alter function trigger_insertion_order_eqn() owner to razor;

