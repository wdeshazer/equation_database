create function trigger_insertion_order_var() returns trigger
    language plpgsql
as
$$
DECLARE
        the_count integer;
    BEGIN
        if new.insertion_order is NULL then
            SELECT INTO the_count COUNT(variable_id) FROM variable_equation WHERE equation_id = new.equation_id;
            new.insertion_order = the_count + 1;
            new.insertion_order_prev := the_count + 1;
        end if;
        RETURN new;
    END;
$$;

alter function trigger_insertion_order_var() owner to razor;

