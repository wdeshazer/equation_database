create function trigger_eqn_group_insert() returns trigger
    language plpgsql
as
$$
BEGIN
        new.modified_at = now();

        if new.modified_by IS NULL THEN
            new.modified_by = new.created_by;
        END IF;

        RETURN new;
    END;
$$;

alter function trigger_eqn_group_insert() owner to razor;

