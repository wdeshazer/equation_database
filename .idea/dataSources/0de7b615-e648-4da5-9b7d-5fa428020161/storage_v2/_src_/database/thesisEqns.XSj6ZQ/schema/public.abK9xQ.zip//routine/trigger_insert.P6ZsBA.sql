create function trigger_insert() returns trigger
    language plpgsql
as
$$
BEGIN

        IF new.image IS NOT NULL THEN
            new.compiled_at = now();
        END IF;

        IF new.modified_by IS NULL THEN
            new.modified_by = new.created_by;
        END IF;

        RETURN new;
    END;
$$;

alter function trigger_insert() owner to razor;

