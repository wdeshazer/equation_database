create function trigger_copy_previous_insertion_order() returns trigger
    language plpgsql
as
$$
BEGIN
        new.insertion_order_prev := old.insertion_order;
        RETURN new;
    END;
$$;

alter function trigger_copy_previous_insertion_order() owner to razor;

