create function trigger_eqn_group_update() returns trigger
    language plpgsql
as
$$
BEGIN
        new.modified_at = now();
        RETURN new;
    END;
$$;

alter function trigger_eqn_group_update() owner to razor;

