create function template_default() returns trigger
    language plpgsql
as
$$
BEGIN
    IF new.template_id IS NULL THEN
        new.template_id = (SELECT id FROM template ORDER BY create_date DESC FETCH FIRST ROW ONLY);
    END IF;
    RETURN new;
END;
$$;

alter function template_default() owner to razor;

