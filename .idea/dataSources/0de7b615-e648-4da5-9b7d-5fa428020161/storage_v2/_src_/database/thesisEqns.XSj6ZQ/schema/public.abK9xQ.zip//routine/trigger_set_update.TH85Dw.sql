create function trigger_set_update() returns trigger
    language plpgsql
as
$$
BEGIN
        new.modified_at = now();

        IF new.image IS NOT NULL THEN
            new.compiled_at = now();
        END IF;

        IF new.latex IS NOT NULL and new.image IS NULL THEN
            new.image_is_dirty = TRUE;
        END IF;

        RETURN new;
    END;
$$;

alter function trigger_set_update() owner to razor;

